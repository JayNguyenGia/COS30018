<?php
echo "<h1>Welcome to Assignment 3 PHP App</h1>";
echo "<p>This is a simple PHP web app deployed on Azure.</p>";
echo "<p>Student: Gia Nguyen Nguyen (104308290)</p>";
?>
